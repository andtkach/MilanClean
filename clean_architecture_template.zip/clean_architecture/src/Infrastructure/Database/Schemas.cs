﻿namespace Infrastructure.Database;

internal static class Schemas
{
    public const string Default = "public";
}
