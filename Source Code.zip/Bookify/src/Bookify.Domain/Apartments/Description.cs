﻿namespace Bookify.Domain.Apartments;

public sealed record Description(string Value);
