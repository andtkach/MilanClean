﻿namespace Bookify.Domain.Apartments;

public sealed record Name(string Value);
