﻿namespace Bookify.Domain.Users;

public sealed record FirstName(string Value);
