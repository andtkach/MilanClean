﻿namespace Bookify.Domain.Users;

public sealed record LastName(string Value);
