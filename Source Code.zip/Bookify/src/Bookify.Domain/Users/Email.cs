﻿namespace Bookify.Domain.Users;

public sealed record Email(string Value);
