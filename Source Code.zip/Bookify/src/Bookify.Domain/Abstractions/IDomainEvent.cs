﻿using MediatR;

namespace Bookify.Domain.Abstractions;

public interface IDomainEvent : INotification
{
}
