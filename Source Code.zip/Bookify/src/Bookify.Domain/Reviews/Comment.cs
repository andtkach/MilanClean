﻿namespace Bookify.Domain.Reviews;

public sealed record Comment(string Value);
