﻿namespace Bookify.Domain.Reviews;

public interface IReviewRepository
{
    void Add(Review review);
}
