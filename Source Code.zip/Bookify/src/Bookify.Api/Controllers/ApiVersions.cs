﻿namespace Bookify.Api.Controllers;

internal static class ApiVersions
{
    public const string V1 = "1";
}
