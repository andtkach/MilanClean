﻿namespace Bookify.Api.Controllers;

internal static class Roles
{
    public const string Registered = "Registered";
}
