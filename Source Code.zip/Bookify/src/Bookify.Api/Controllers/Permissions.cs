﻿namespace Bookify.Api.Controllers;

internal static class Permissions
{
    public const string UsersRead = "users:read";
}
