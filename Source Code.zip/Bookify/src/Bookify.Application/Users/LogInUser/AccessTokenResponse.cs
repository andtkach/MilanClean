﻿namespace Bookify.Application.Users.LogInUser;

public sealed record AccessTokenResponse(string AccessToken);
